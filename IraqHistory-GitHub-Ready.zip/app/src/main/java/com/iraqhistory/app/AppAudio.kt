package com.iraqhistory.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Single owner of all audio: background music, anthem (independent track), click sounds. */
object AppAudio {
    private lateinit var ctx: Context
    private lateinit var prefs: android.content.SharedPreferences
    private var bg: MediaPlayer? = null
    private var anthem: MediaPlayer? = null
    private var pool: SoundPool? = null
    private var clickId = 0

    var musicOn by mutableStateOf(true); private set
    var volume by mutableStateOf(0.4f); private set
    var muteAll by mutableStateOf(false); private set
    var clickOn by mutableStateOf(true); private set
    var anthemPlaying by mutableStateOf(false); private set
    var anthemVolume by mutableStateOf(0.8f); private set
    var favorites by mutableStateOf(setOf<String>()); private set

    fun init(c: Context) {
        if (this::ctx.isInitialized) return
        ctx = c.applicationContext
        prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        musicOn = prefs.getBoolean("musicOn", true)
        volume = prefs.getFloat("volume", 0.4f)
        muteAll = prefs.getBoolean("muteAll", false)
        clickOn = prefs.getBoolean("clickOn", true)
        favorites = prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet()
        pool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build()).build()
        clickId = pool!!.load(ctx, R.raw.click, 1)
    }

    private fun rawId(name: String) = ctx.resources.getIdentifier(name, "raw", ctx.packageName)
    /** True if a licensed bg_music.* file was added to res/raw. */
    fun hasMusic() = rawId("bg_music") != 0
    private fun effBg() = if (muteAll) 0f else volume

    fun setMusicOn(v: Boolean) { musicOn = v; prefs.edit().putBoolean("musicOn", v).apply(); refreshBg() }
    fun setVolume(v: Float) { volume = v; prefs.edit().putFloat("volume", v).apply(); bg?.setVolume(effBg(), effBg()) }
    fun setMute(v: Boolean) {
        muteAll = v; prefs.edit().putBoolean("muteAll", v).apply()
        bg?.setVolume(effBg(), effBg()); applyAnthemVol()
    }
    fun setClick(v: Boolean) { clickOn = v; prefs.edit().putBoolean("clickOn", v).apply() }

    fun resumeBg() = refreshBg()
    fun pauseBg() { bg?.takeIf { it.isPlaying }?.pause() }
    private fun refreshBg() {
        if (anthemPlaying || !musicOn || muteAll || !hasMusic()) { pauseBg(); return }
        if (bg == null) bg = MediaPlayer.create(ctx, rawId("bg_music"))?.apply { isLooping = true }
        bg?.setVolume(effBg(), effBg()); bg?.start()
    }

    fun click() {
        if (clickOn && !muteAll) pool?.play(clickId, 0.5f, 0.5f, 1, 0, 1f)
    }

    // ---- Anthem (separate from background music; never auto-plays) ----
    private fun applyAnthemVol() { val v = if (muteAll) 0f else anthemVolume; anthem?.setVolume(v, v) }
    fun setAnthemVolume(v: Float) { anthemVolume = v; applyAnthemVol() }
    fun anthemToggle() {
        if (anthem == null) anthem = MediaPlayer.create(ctx, R.raw.national_anthem)?.apply {
            setOnCompletionListener { anthemPlaying = false; refreshBg() }
        }
        val a = anthem ?: return
        if (a.isPlaying) { a.pause(); anthemPlaying = false; refreshBg() }
        else { pauseBg(); applyAnthemVol(); a.start(); anthemPlaying = true }
    }
    fun anthemPos() = anthem?.currentPosition ?: 0
    fun anthemDur() = anthem?.duration ?: 0
    fun anthemSeek(ms: Int) { anthem?.seekTo(ms) }
    fun anthemStop() {
        anthem?.let { if (it.isPlaying) it.pause(); it.seekTo(0) }
        anthemPlaying = false; refreshBg()
    }
    fun releaseAll() { anthem?.release(); anthem = null; bg?.release(); bg = null; anthemPlaying = false }

    fun toggleFav(name: String) {
        favorites = if (name in favorites) favorites - name else favorites + name
        prefs.edit().putStringSet("fav", favorites).apply()
    }
}
