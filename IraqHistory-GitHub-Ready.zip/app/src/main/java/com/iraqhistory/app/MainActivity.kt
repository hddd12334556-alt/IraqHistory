package com.iraqhistory.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppAudio.init(this)
        AppLanguage.init(this)
        setContent { AppRoot() }
    }
    override fun onStart() { super.onStart(); AppAudio.resumeBg() }
    override fun onStop() {
        super.onStop(); AppAudio.pauseBg()
        if (AppAudio.anthemPlaying) AppAudio.anthemToggle()
    }
    override fun onDestroy() { super.onDestroy(); if (isFinishing) AppAudio.releaseAll() }
}
