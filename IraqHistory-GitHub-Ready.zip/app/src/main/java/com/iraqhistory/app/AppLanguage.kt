package com.iraqhistory.app

import android.content.Context
import androidx.compose.runtime.mutableStateOf

object AppLanguage {
    val code = mutableStateOf("ar")
    fun init(context: Context) {
        code.value = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE).getString("language", "ar") ?: "ar"
    }
    fun set(context: Context, language: String) {
        code.value = language
        context.getSharedPreferences("app_settings", Context.MODE_PRIVATE).edit().putString("language", language).apply()
    }
}

private val translations = mapOf(
"تاريخ العراق" to listOf("تاريخ العراق", "History of Iraq", "Histoire de l’Irak"),
"اكتشف تاريخ العراق" to listOf("اكتشف تاريخ العراق", "Discover Iraq’s History", "Découvrez l’histoire de l’Irak"),
"من حضارات بلاد الرافدين إلى العراق الحديث" to listOf("من حضارات بلاد الرافدين إلى العراق الحديث", "From Mesopotamian civilizations to modern Iraq", "Des civilisations mésopotamiennes à l’Irak moderne"),
"تاريخ العراق عبر العصور" to listOf("تاريخ العراق عبر العصور", "Iraq Through the Ages", "L’Irak à travers les âges"),
"محافظات العراق" to listOf("محافظات العراق", "Iraqi Governorates", "Gouvernorats irakiens"),
"عدد محافظات العراق" to listOf("عدد محافظات العراق", "Number of Governorates", "Nombre de gouvernorats"),
"سكان العراق" to listOf("سكان العراق", "Population of Iraq", "Population de l’Irak"),
"النشيد الوطني العراقي" to listOf("النشيد الوطني العراقي", "Iraqi National Anthem", "Hymne national irakien"),
"الإعدادات الصوتية" to listOf("الإعدادات الصوتية", "Audio Settings", "Paramètres audio"),
"إعدادات اللغة" to listOf("إعدادات اللغة", "Language Settings", "Paramètres de langue"),
"اختر لغة التطبيق" to listOf("اختر لغة التطبيق", "Choose app language", "Choisissez la langue de l’application"),
"العربية" to listOf("العربية", "Arabic", "Arabe"),
"الإنجليزية" to listOf("الإنجليزية", "English", "Anglais"),
"الفرنسية" to listOf("الفرنسية", "French", "Français"),
"المصادر والمراجع" to listOf("المصادر والمراجع", "Sources and References", "Sources et références"),
"حول التطبيق" to listOf("حول التطبيق", "About the App", "À propos de l’application"),
"العصور السومرية والبابلية والآشورية والإسلامية والحديثة" to listOf("العصور السومرية والبابلية والآشورية والإسلامية والحديثة", "Sumerian, Babylonian, Assyrian, Islamic and modern eras", "Époques sumérienne, babylonienne, assyrienne, islamique et moderne"),
"معلومات إحصائية مع توضيح المصادر والسنوات المرجعية" to listOf("معلومات إحصائية مع توضيح المصادر والسنوات المرجعية", "Statistics with sources and reference years", "Statistiques avec sources et années de référence"),
"استمع إلى النشيد" to listOf("استمع إلى النشيد", "Listen to the anthem", "Écouter l’hymne"),
"الموسيقى وأصوات اللمس" to listOf("الموسيقى وأصوات اللمس", "Music and touch sounds", "Musique et sons tactiles"),
"رجوع" to listOf("رجوع", "Back", "Retour"),
"الرئيسية" to listOf("الرئيسية", "Home", "Accueil"),
"ابحث عن محافظة" to listOf("ابحث عن محافظة", "Search governorates", "Rechercher un gouvernorat"),
"المفضلة فقط" to listOf("المفضلة فقط", "Favorites only", "Favoris uniquement"),
"لا توجد نتائج." to listOf("لا توجد نتائج.", "No results.", "Aucun résultat."),
"محطات رئيسية" to listOf("محطات رئيسية", "Key highlights", "Points clés"),
"ملاحظة مرجعية" to listOf("ملاحظة مرجعية", "Reference note", "Note de référence"),
"المركز الإداري" to listOf("المركز الإداري", "Administrative center", "Centre administratif"),
"معالم بارزة" to listOf("معالم بارزة", "Notable landmarks", "Sites remarquables"),
"أنشطة اقتصادية" to listOf("أنشطة اقتصادية", "Economic activities", "Activités économiques"),
"الموسيقى الخلفية" to listOf("الموسيقى الخلفية", "Background music", "Musique de fond"),
"مستوى الصوت" to listOf("مستوى الصوت", "Volume", "Volume sonore"),
"كتم جميع الأصوات" to listOf("كتم جميع الأصوات", "Mute all sounds", "Couper tous les sons"),
"أصوات اللمس" to listOf("أصوات اللمس", "Touch sounds", "Sons tactiles"),
"تشغيل" to listOf("تشغيل", "Play", "Lecture"),
"إيقاف مؤقت" to listOf("إيقاف مؤقت", "Pause", "Pause"),
"اضغط تشغيل للاستماع (لا يعمل تلقائياً)." to listOf("اضغط تشغيل للاستماع (لا يعمل تلقائياً).", "Press Play to listen (does not autoplay).", "Appuyez sur Lecture pour écouter (sans lecture automatique)."),
"سكان العراق" to listOf("سكان العراق", "Population of Iraq", "Population de l’Irak"),
"المحافظات الإدارية" to listOf("المحافظات الإدارية", "Administrative governorates", "Gouvernorats administratifs"),
"عرض المحافظات" to listOf("عرض المحافظات", "View governorates", "Voir les gouvernorats"),
"الانتقال إلى القائمة والتفاصيل" to listOf("الانتقال إلى القائمة والتفاصيل", "Open the list and details", "Ouvrir la liste et les détails"),
"المصادر الإحصائية" to listOf("المصادر الإحصائية", "Statistical sources", "Sources statistiques"),
"المراجع العامة المعتمدة للتحقق" to listOf("المراجع العامة المعتمدة للتحقق", "General references for verification", "Références générales de vérification"),
"تم حفظ اختيار اللغة" to listOf("تم حفظ اختيار اللغة", "Language preference saved", "Préférence de langue enregistrée"),
"سومر وبدايات المدن" to listOf("سومر وبدايات المدن", "Sumer and the First Cities", "Sumer et les premières villes"),
"أكد وبابل وآشور" to listOf("أكد وبابل وآشور", "Akkad, Babylon and Assyria", "Akkad, Babylone et Assyrie"),
"العصر الأخميني والهلنستي والفرثي والساساني" to listOf("العصر الأخميني والهلنستي والفرثي والساساني", "Achaemenid, Hellenistic, Parthian and Sasanian Periods", "Périodes achéménide, hellénistique, parthe et sassanide"),
"العراق في العصور الإسلامية" to listOf("العراق في العصور الإسلامية", "Iraq in the Islamic Eras", "L’Irak à l’époque islamique"),
"العهد العثماني والدولة الحديثة" to listOf("العهد العثماني والدولة الحديثة", "Ottoman Rule and the Modern State", "Période ottomane et État moderne"),
"بغداد" to listOf("بغداد", "Baghdad", "Bagdad"), "البصرة" to listOf("البصرة", "Basra", "Bassora"),
"نينوى" to listOf("نينوى", "Nineveh", "Ninive"), "أربيل" to listOf("أربيل", "Erbil", "Erbil"),
"السليمانية" to listOf("السليمانية", "Sulaymaniyah", "Souleimaniye"), "دهوك" to listOf("دهوك", "Duhok", "Dohouk"),
"كركوك" to listOf("كركوك", "Kirkuk", "Kirkouk"), "الأنبار" to listOf("الأنبار", "Anbar", "Al-Anbar"),
"صلاح الدين" to listOf("صلاح الدين", "Saladin", "Salah ad-Din"), "ديالى" to listOf("ديالى", "Diyala", "Diyala"),
"واسط" to listOf("واسط", "Wasit", "Wasit"), "بابل" to listOf("بابل", "Babylon", "Babylone"),
"كربلاء" to listOf("كربلاء", "Karbala", "Kerbala"), "النجف" to listOf("النجف", "Najaf", "Nadjaf"),
"القادسية" to listOf("القادسية", "Al-Qadisiyyah", "Al-Qadisiyya"), "المثنى" to listOf("المثنى", "Al-Muthanna", "Al-Muthanna"),
"ذي قار" to listOf("ذي قار", "Dhi Qar", "Dhi Qar"), "ميسان" to listOf("ميسان", "Maysan", "Maysan"), "حلبجة" to listOf("حلبجة", "Halabja", "Halabja"),
"محطات رئيسية" to listOf("محطات رئيسية", "Key highlights", "Points clés"),
"ملاحظة مرجعية" to listOf("ملاحظة مرجعية", "Reference note", "Note de référence"),
"المركز: بغداد" to listOf("المركز: بغداد", "Center: Baghdad", "Centre : Bagdad")
)

fun tr(text: String): String {
    val index = when (AppLanguage.code.value) { "en" -> 1; "fr" -> 2; else -> 0 }
    return translations[text]?.get(index) ?: text
}
