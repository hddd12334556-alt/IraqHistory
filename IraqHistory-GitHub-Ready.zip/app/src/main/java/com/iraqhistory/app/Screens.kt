@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.iraqhistory.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import kotlinx.coroutines.delay

val RoyalBlue = Color(0xFF0B1530); val Gold = Color(0xFFC9A227); val Ivory = Color(0xFFF5EFE0); val CardBg = Color(0xFF16254D)

fun Modifier.sfx(onClick: () -> Unit) = clickable { AppAudio.click(); onClick() }

@Composable fun AppRoot() {
    CompositionLocalProvider(LocalLayoutDirection provides if (AppLanguage.code.value == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = RoyalBlue, surface = CardBg, onSurface = Ivory, onBackground = Ivory)) {
        val nav = rememberNavController()
        NavHost(nav, "splash") {
            composable("splash") { Splash(nav) }
            composable("home") { Home(nav) }
            composable("history") { HistoryList(nav) }
            composable("history/{i}") { e -> val i = e.arguments!!.getString("i")!!.toInt()
                HistoryDetail(historyEntries[i], nav) }
            composable("provinces") { Provinces(nav) }
            composable("province/{n}") { e -> val p = provinces.first { it.name == e.arguments!!.getString("n") }; ProvinceDetail(p, nav) }
            composable("population") { Page("سكان العراق", nav) {
                Text("المحافظات الإدارية", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                Text("يضم التطبيق ${provinces.size} محافظة في هذه النسخة، ومنها حلبجة. قد تختلف الأرقام في المصادر الأقدم تبعاً لتاريخ تحديث التقسيم الإداري.", Modifier.padding(12.dp), lineHeight = 25.sp)
                Text("لم تُدرج أعداد السكان حتى الآن لتجنب عرض تقديرات غير مؤرخة على أنها أرقام رسمية. ستُضاف عند ربط كل رقم بسنة مرجعية ومصدر حكومي واضح.", Modifier.padding(12.dp), color = Gold, lineHeight = 25.sp)
                BigCard("عرض المحافظات", "الانتقال إلى القائمة والتفاصيل") { nav.navigate("provinces") }
                BigCard("المصادر الإحصائية", "المراجع العامة المعتمدة للتحقق") { nav.navigate("sources") }
            } }
            composable("audio") { AudioSettings(nav) }
            composable("language") { LanguageSettings(nav) }
            composable("anthem") { Anthem(nav) }
            composable("sources") { Page("المصادر والمراجع", nav) {
                Text("مراجع عامة للبدء والتحقق من المعلومات:", Modifier.padding(12.dp), color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                generalSources.forEachIndexed { index, source -> BigCard("${index + 1}. ${source}", "تحقق من أحدث النسخ الرسمية قبل اعتماد أي رقم أو معلومة في إصدار منشور.") { } }
                Text("ملاحظة: المحتوى التاريخي موجز وتعليمي، ولا يغني عن المراجع المتخصصة. ستحتاج بيانات السكان إلى سنة مرجعية محددة.", Modifier.padding(12.dp), lineHeight = 24.sp)
            } }
            composable("about") { Page("حول التطبيق", nav) { Text("تطبيق «تاريخ العراق» – الإصدار 0.1 (هيكل أولي).\nالنشيد: ملف صوتي قدّمه صاحب المشروع؛ يجب التأكد من ترخيصه قبل النشر.", Modifier.padding(16.dp)) } }
        }
    }
    }
}

@Composable fun Splash(nav: NavHostController) {
    LaunchedEffect(Unit) { delay(1500); nav.navigate("home") { popUpTo("splash") { inclusive = true } } }
    Box(Modifier.fillMaxSize().background(RoyalBlue), Alignment.Center) { Text(tr("تاريخ العراق"), color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Bold) }
}

@Composable fun Page(title: String, nav: NavHostController, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text(tr(title)) },
        navigationIcon = { IconButton({ AppAudio.click(); nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } },
        actions = { IconButton({ AppAudio.click(); nav.navigate("home") { popUpTo("home") { inclusive = true } } }) { Icon(Icons.Filled.Home, "الرئيسية") } },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = CardBg, titleContentColor = Gold, navigationIconContentColor = Gold, actionIconContentColor = Gold)) }
    ) { Column(Modifier.padding(it).fillMaxSize().background(RoyalBlue).verticalScroll(rememberScrollState()).padding(8.dp), content = content) }
}

@Composable fun Stage2(t: String) = Text(t, Modifier.padding(16.dp), color = Ivory, lineHeight = 26.sp)

@Composable fun HistoryDetail(entry: HistoryEntry, nav: NavHostController) = Page(entry.title, nav) {
    Text(entry.period, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    Text(entry.body, Modifier.padding(14.dp), fontSize = 17.sp, lineHeight = 29.sp)
    Text("محطات رئيسية", Modifier.padding(start = 14.dp, top = 8.dp), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    entry.highlights.forEach { BigCard(it, "") { } }
    Text("ملاحظة مرجعية", Modifier.padding(start = 14.dp, top = 8.dp), color = Gold, fontWeight = FontWeight.Bold)
    Text(entry.sourceNote, Modifier.padding(14.dp), lineHeight = 25.sp)
}

@Composable fun BigCard(title: String, desc: String, onClick: () -> Unit) =
    Card(Modifier.fillMaxWidth().padding(8.dp).sfx(onClick), colors = CardDefaults.cardColors(containerColor = CardBg)) {
        Column(Modifier.padding(18.dp)) { Text(tr(title), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold); if (desc.isNotEmpty()) Text(tr(desc), color = Ivory) } }

@Composable fun Home(nav: NavHostController) = Page("اكتشف تاريخ العراق", nav) {
    Text("من حضارات بلاد الرافدين إلى العراق الحديث", Modifier.padding(horizontal = 16.dp, vertical = 6.dp), color = Ivory, fontSize = 16.sp)
    BigCard("تاريخ العراق", "العصور السومرية والبابلية والآشورية والإسلامية والحديثة") { nav.navigate("history") }
    BigCard("عدد محافظات العراق", "${provinces.size} محافظة في بيانات هذا الإصدار") { nav.navigate("provinces") }
    BigCard("سكان العراق", "معلومات إحصائية مع توضيح المصادر والسنوات المرجعية") { nav.navigate("population") }
    BigCard("النشيد الوطني العراقي", "استمع إلى النشيد") { nav.navigate("anthem") }
    BigCard("الإعدادات الصوتية", "الموسيقى وأصوات اللمس") { nav.navigate("audio") }
    BigCard("إعدادات اللغة", "اختر لغة التطبيق") { nav.navigate("language") }
    BigCard("المصادر والمراجع", "") { nav.navigate("sources") }
    BigCard("حول التطبيق", "") { nav.navigate("about") }
}

@Composable fun HistoryList(nav: NavHostController) = Page("تاريخ العراق عبر العصور", nav) {
    Text("رحلة مختصرة من المدن الأولى إلى العراق المعاصر", Modifier.padding(12.dp), color = Ivory, fontSize = 16.sp)
    historyEntries.forEachIndexed { i, entry -> BigCard(entry.title, entry.period) { nav.navigate("history/$i") } }
}

@Composable fun Provinces(nav: NavHostController) {
    var q by remember { mutableStateOf("") }; var favOnly by remember { mutableStateOf(false) }
    val fav = AppAudio.favorites
    val list = provinces.sortedBy { it.name }.filter { it.name.contains(q.trim()) && (!favOnly || it.name in fav) }
    Page("محافظات العراق", nav) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(8.dp), label = { Text(tr("ابحث عن محافظة")) }, singleLine = true)
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Switch(favOnly, { AppAudio.click(); favOnly = it }); Spacer(Modifier.width(8.dp)); Text(tr("المفضلة فقط")) }
        if (list.isEmpty()) Text(tr("لا توجد نتائج."), Modifier.padding(16.dp))
        list.forEach { p -> Card(Modifier.fillMaxWidth().padding(6.dp).sfx { nav.navigate("province/${p.name}") }, colors = CardDefaults.cardColors(containerColor = CardBg)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(p.name, color = Gold, fontSize = 18.sp); Text("المركز: ${p.center}") }
                TextButton({ AppAudio.toggleFav(p.name) }) { Text(if (p.name in fav) "★" else "☆", color = Gold, fontSize = 24.sp) } } } }
    }
}

@Composable fun ProvinceDetail(p: Province, nav: NavHostController) = Page(p.name, nav) {
    Text("المركز الإداري: ${p.center}", Modifier.padding(16.dp), fontSize = 18.sp, color = Gold)
    Text(p.note, Modifier.padding(horizontal = 16.dp), lineHeight = 25.sp)
    Text("معالم بارزة", Modifier.padding(start = 16.dp, top = 16.dp), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text(p.landmarks, Modifier.padding(16.dp), lineHeight = 25.sp)
    Text("أنشطة اقتصادية", Modifier.padding(start = 16.dp, top = 8.dp), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text(p.economy, Modifier.padding(16.dp), lineHeight = 25.sp)
    Text("لا يتضمن هذا الإصدار تعداداً سكانياً غير مؤرخ. تختلف البيانات بحسب سنة الإحصاء والمصدر.", Modifier.padding(16.dp), color = Ivory, lineHeight = 24.sp)
}

@Composable fun SwitchRow(t: String, v: Boolean, f: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(t, Modifier.weight(1f)); Switch(v, { AppAudio.click(); f(it) }) }

@Composable fun AudioSettings(nav: NavHostController) = Page("الإعدادات الصوتية", nav) {
    SwitchRow("الموسيقى الخلفية", AppAudio.musicOn) { AppAudio.setMusicOn(it) }
    if (!AppAudio.hasMusic()) Text("لا يوجد ملف موسيقى بعد: أضف ملفاً مرخّصاً باسم bg_music إلى res/raw.", Modifier.padding(horizontal = 12.dp), color = Gold)
    Text("مستوى الصوت: ${(AppAudio.volume * 100).toInt()}%", Modifier.padding(12.dp))
    Slider(AppAudio.volume, { AppAudio.setVolume(it) }, Modifier.padding(horizontal = 12.dp))
    SwitchRow("كتم جميع الأصوات", AppAudio.muteAll) { AppAudio.setMute(it) }
    SwitchRow("أصوات اللمس", AppAudio.clickOn) { AppAudio.setClick(it) }
}

@Composable fun Anthem(nav: NavHostController) {
    DisposableEffect(Unit) { onDispose { AppAudio.anthemStop() } }
    var pos by remember { mutableIntStateOf(0) }
    LaunchedEffect(AppAudio.anthemPlaying) { while (AppAudio.anthemPlaying) { pos = AppAudio.anthemPos(); delay(300) } }
    Page("النشيد الوطني العراقي", nav) {
        Text("اضغط تشغيل للاستماع (لا يعمل تلقائياً).", Modifier.padding(16.dp))
        val dur = AppAudio.anthemDur().coerceAtLeast(1)
        Slider(pos.toFloat() / dur, { pos = (it * dur).toInt(); AppAudio.anthemSeek(pos) }, Modifier.padding(horizontal = 16.dp))
        Button({ AppAudio.click(); AppAudio.anthemToggle() }, Modifier.align(Alignment.CenterHorizontally)) { Text(if (AppAudio.anthemPlaying) "إيقاف مؤقت" else "تشغيل") }
        Text("مستوى الصوت", Modifier.padding(16.dp))
        Slider(AppAudio.anthemVolume, { AppAudio.setAnthemVolume(it) }, Modifier.padding(horizontal = 16.dp))
    }
}


@Composable fun LanguageSettings(nav: NavHostController) {
    val context = LocalContext.current
    Page("إعدادات اللغة", nav) {
        Text(tr("اختر لغة التطبيق"), Modifier.padding(16.dp), color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        listOf("ar" to "العربية", "en" to "الإنجليزية", "fr" to "الفرنسية").forEach { (code, label) ->
            Row(Modifier.fillMaxWidth().padding(8.dp).sfx { AppLanguage.set(context, code) }.background(CardBg).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(when(code) { "ar" -> "العربية"; "en" -> "English"; else -> "Français" }, Modifier.weight(1f), color = Ivory, fontSize = 18.sp)
                RadioButton(selected = AppLanguage.code.value == code, onClick = { AppLanguage.set(context, code) })
            }
        }
        Text(tr("تم حفظ اختيار اللغة"), Modifier.padding(16.dp), color = Gold)
    }
}
