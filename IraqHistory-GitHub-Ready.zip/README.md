# تاريخ العراق — مشروع Android

تطبيق تعليمي باللغة العربية (RTL) باستخدام Kotlin وJetpack Compose.

## ما يتضمنه الإصدار المطوّر
- واجهة رئيسية وأقسام تاريخ العراق، المحافظات، السكان، النشيد، إعدادات الصوت، المصادر، وحول التطبيق.
- خمس وحدات تاريخية تمهيدية عن سومر، وأكد وبابل وآشور، والعصور الإمبراطورية، والعصر الإسلامي، والعراق الحديث.
- قائمة 19 محافظة مع المراكز الإدارية ومعلومات موجزة عن المعالم والأنشطة الاقتصادية.
- بحث في المحافظات وإمكانية وضعها في المفضلة.
- تشغيل النشيد المرفق والتحكم بالصوت وأصوات اللمس.
- أيقونة مستوحاة بشكل مبسط من الثور المجنح الرافديني، بألوان الأزرق الداكن والذهبي.
- صفحة للمصادر وملاحظة صريحة بشأن الأرقام السكانية التي لم تُدرج من دون سنة ومصدر محددين.

## بناء APK
1. افتح مجلد `IraqHistory` في Android Studio حديث.
2. استخدم JDK 17 ودع Gradle يزامن الاعتماديات.
3. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. ملف APK التجريبي يظهر عادة في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات قبل النشر
- المشروع لا يتضمن Gradle Wrapper؛ يمكن فتحه في Android Studio ليولّد إعدادات البناء المناسبة أو إضافة Wrapper عبر Gradle مثبت.
- لم تُضف أرقام سكان غير مؤرخة؛ يجب إدراج الأرقام من الجداول الرسمية مع سنة الإحصاء والمصدر.
- محتوى التاريخ ملخص تمهيدي ويحتاج مراجعة أكاديمية قبل اعتباره مرجعاً نهائياً.
- تحقق من ترخيص ملف النشيد الصوتي قبل التوزيع العام.
- لا تعتبر النسخة APK جاهزة حتى يتم بناؤها واختبارها على جهاز فعلي.

## Language settings (updated)
The app now includes a Language Settings screen with Arabic (default), English, and French. The selection is saved in SharedPreferences and applied immediately, including switching the layout direction to RTL for Arabic and LTR for English/French. The language dictionary covers main navigation, common controls, major section headings, and selected history/province names. Some long historical descriptions and province detail content remain Arabic and should be fully translated/reviewed before public release.
